# -*- coding: utf-8 -*-
__version__ = '1.2'
__title__ = "winsys"
__description__ = "WinSys: the Python Windows Administrator's Toolkit"
__author__ = "Tim Golden"
__email__ = "mail@timgolden.me.uk"
__url__ = "https://winsys.readthedocs.io/"
__license__ = "MIT"
